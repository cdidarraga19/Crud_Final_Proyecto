
function validar (){
	var Id,Nombre,PrecioUni,PrecioMayor,Stock,Descripcion,Cantidad,UnidadMedida,FKMarca,FKCategoria;
	var Id = document.getElementById("IdDelproducto").value;
	var Nombre = document.getElementById("Nombreproducto").value;
	var PrecioUni = document.getElementById("PrecioUnidad").value;
	var PrecioMayor = document.getElementById("Precioalmayor").value;
	var Stock = document.getElementById("Stockdisponible").value;
	var Descripcion = document.getElementById("Descripción").value;
	var Cantidad = document.getElementById("Cantidad").value;
	var UnidadMedida = document.getElementById("Unidadmedidacantidad").value;
	var FKMarca = document.getElementById("FKIDmarca").value;
	var FKCategoria = document.getElementById("FKIFCategoriaProducto").value;
	expresión1= /^[a-zA-zÁ-ý\s]/

	

	if (Id==0){
		Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debes ingresar el ID del producto',
		  })		
		  return false;
	}

	if (isNaN (Id)){
        Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debe ingresar números para el ID',
		  })
        return false;
    }

	if(Nombre==0){
        Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debe escribir un nombre para el producto',
		  })
		return false;
    }

	if(Nombre.length>30){
		Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'El nombre es muy largo',
		  })
		return false;
    }
	
	if (PrecioUni==0){
		Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debe ingresar el precio por unidad del producto',
		  })
		return false;
	}

	if (isNaN (PrecioUni)){
		Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debe ingresar números para el precio',
		  })
        return false;
    }

	if (PrecioMayor==0){
		Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debe ingresar el precio al por mayor del producto',
		  })
		return false;
	}

	if (isNaN (PrecioMayor)){
        Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debe ingresar números para el precio al por mayor',
		  })
        return false;
    }

	if (Stock==0){
		Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debe ingresar el Stock disponible',
		  })
		return false;
	}

	if (isNaN (Stock)){
        Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debe ingresar números para el stock',
		  })
        return false;
    }

	if(Descripcion==0){
		Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debe escribir una descripción para el producto',
		  })
		return false;
    }

	if(Descripcion.length>50){
        Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'La descripcion es muy larga',
		  })
		return false;
    }
	
	if (Cantidad==0){
		Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debe ingresar la cantidad del producto',
		  })
		return false;
	}

	if (isNaN (Cantidad)){
		Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debe ingresar números para la cantidad',
		  })
        return false;
    }

	if (UnidadMedida==0){
		Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debe ingresar la unidad de medida del producto',
		  })
		return false;
	}

	if(UnidadMedida.length>5){
        Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'La unidad de medida es muy largo',
		  })
		return false;
    }

	if (FKMarca==0){
		Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debe ingresar el ID de la marca del producto',
		  })
		return false;
	}

	if (isNaN (FKMarca)){
        Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debe ingresar números para el ID de la marca',
		  })
        return false;
    }

	if (FKCategoria==0){
		Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debe ingresar el ID de la categoria del producto',
		  })
		return false;
	}

	if (isNaN (FKCategoria)){
        Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: '	Debe ingresar números para el ID de la categoria del producto',
		  })
        return false;
    }


}
