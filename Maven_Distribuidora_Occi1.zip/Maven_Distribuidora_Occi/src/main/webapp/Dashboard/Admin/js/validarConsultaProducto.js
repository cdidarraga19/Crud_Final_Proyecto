function validar (){
    var Id;

    var Id = document.getElementById("IdDelproducto").value;

    if (Id==0){
		Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debes ingresar el ID del producto',
		  })		
		  return false;
	}

	if (isNaN (Id)){
        Swal.fire({
			icon: 'error',
			title: 'Oops...',
			text: 'Debe ingresar números para el ID',
		  })
        return false;
    }
}